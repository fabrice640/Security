<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://WordPress3D
 * @since             1.0.0
 * @package           Wordpress3d
 *
 * @wordpress-plugin
 * Plugin Name:       WordPress3D
 * Plugin URI:        https://github.com/fabrice640/WordPress3D
 * Description:       To creating a WordPress websites in 3D via threejs.
 * Version:           1.0.0
 * Author:            Fabris Vulpio
 * Author URI:        https://github.com/fabrice640/WordPress3D
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       wordpress3d
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define( 'WORDPRESS3D_VERSION', '1.0.0' );

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-wordpress3d-activator.php
 */
function activate_wordpress3d() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-wordpress3d-activator.php';
	Wordpress3d_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-wordpress3d-deactivator.php
 */
function deactivate_wordpress3d() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-wordpress3d-deactivator.php';
	Wordpress3d_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_wordpress3d' );
register_deactivation_hook( __FILE__, 'deactivate_wordpress3d' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-wordpress3d.php';

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_wordpress3d() {

	$plugin = new Wordpress3d();
	$plugin->run();

}
run_wordpress3d();
