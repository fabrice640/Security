<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://WordPress3D
 * @since      1.0.0
 *
 * @package    Wordpress3d
 * @subpackage Wordpress3d/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Wordpress3d
 * @subpackage Wordpress3d/includes
 * @author     Fabris Vulpio <fvulpio50@gmail.com>
 */
class Wordpress3d_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
