<?php

/**
 * Fired during plugin activation
 *
 * @link       https://WordPress3D
 * @since      1.0.0
 *
 * @package    Wordpress3d
 * @subpackage Wordpress3d/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Wordpress3d
 * @subpackage Wordpress3d/includes
 * @author     Fabris Vulpio <fvulpio50@gmail.com>
 */
class Wordpress3d_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
