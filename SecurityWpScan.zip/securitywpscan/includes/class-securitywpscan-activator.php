<?php

/**
 * Fired during plugin activation
 *
 * @link       https://github.com/fabrice640/Security/
 * @since      1.0.0
 *
 * @package    Securitywpscan
 * @subpackage Securitywpscan/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Securitywpscan
 * @subpackage Securitywpscan/includes
 * @author     Fabrice <fvulpio50@gmail.com>
 */
class Securitywpscan_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
