<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://github.com/fabrice640/Security/
 * @since      1.0.0
 *
 * @package    Securitywpscan
 * @subpackage Securitywpscan/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Securitywpscan
 * @subpackage Securitywpscan/includes
 * @author     Fabrice <fvulpio50@gmail.com>
 */
class Securitywpscan_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
