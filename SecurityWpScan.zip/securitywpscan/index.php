
<?php


function Security(){

$user = $_SERVER['HTTP_USER_AGENT'];

$remote = $_SERVER['REMOTE_ADDR'];

$get = $_SERVER['HTTP_'];

$self = $_SERVER['PHP_SELF'];
$server_name = $_SERVER['SERVER_NAME'];
$host =  $_SERVER['HTTP_HOST'];
$http = $_SERVER['HTTP_REFERER'];
$script_name = $_SERVER['SCRIPT_NAME'];


md5(sha512(($user . $remote . $get . $self . $server_name . $host . $http . $script_name)));




}


Security();
